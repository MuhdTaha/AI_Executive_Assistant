import { Controller } from '@nestjs/common';

@Controller('planning')
export class PlanningController {}
